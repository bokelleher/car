jQuery(document).ready(function($) {
    const btn = $('<a href="admin.php?page=car_add_church" class="page-title-action">Add New Church</a>');
    $('.wrap h1').append(btn);
});
