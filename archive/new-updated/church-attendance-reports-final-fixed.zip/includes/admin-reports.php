<?php
function car_render_reports_list_page() {
    echo '<div class="wrap"><h1>Submitted Attendance Reports</h1>';
    echo '<table class="widefat fixed striped"><thead><tr>
        <th>Date</th><th>Church</th><th>In-Person</th><th>Online</th></tr></thead><tbody>';

    $reports = get_posts([
        'post_type' => 'attendance_report',
        'posts_per_page' => -1,
    ]);

    foreach ($reports as $report) {
        $church_id = get_post_meta($report->ID, 'church_id', true);
        $term = get_term($church_id);
        $church_name = (!is_wp_error($term) && isset($term->name)) ? $term->name : 'Unknown';
        $in_person = get_post_meta($report->ID, 'in_person', true);
        $online = get_post_meta($report->ID, 'online', true);

        echo '<tr>';
        echo '<td>' . esc_html(get_the_date('', $report)) . '</td>';
        echo '<td>' . esc_html($church_name) . '</td>';
        echo '<td>' . esc_html($in_person) . '</td>';
        echo '<td>' . esc_html($online) . '</td>';
        echo '</tr>';
    }

    echo '</tbody></table></div>';
}

add_action('admin_menu', function() {
    add_submenu_page(
        'car_reports',
        'Reports',
        'Reports',
        'manage_options',
        'car_reports_list',
        'car_render_reports_list_page'
    );
});
