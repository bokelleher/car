<div id="car-church-modal" style="display:none;">
    <form id="car-church-form">
        <input type="hidden" name="id" value="">
        <p><label>Name: <input type="text" name="name"></label></p>
        <p><label>Slug: <input type="text" name="slug"></label></p>
        <p><label>Pastor: <input type="text" name="pastor"></label></p>
        <p><label>City: <input type="text" name="city"></label></p>
        <p><label>Website: <input type="url" name="website"></label></p>
        <button type="submit" class="button button-primary">Save Church</button>
    </form>
</div>
