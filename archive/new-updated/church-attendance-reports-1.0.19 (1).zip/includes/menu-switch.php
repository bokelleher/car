<?php
// Adds custom admin menu for Church Attendance Reports
add_action('admin_menu', function() {
    add_menu_page(
        'Attendance Reports',
        'Attendance Reports',
        'manage_options',
        'car_reports',
        'car_render_reports_page',
        'dashicons-chart-bar',
        26
    );
});

function car_render_reports_page() {
    echo '<div class="wrap"><h1>Attendance Reports</h1><p>This page will show a summary or links to key reporting functions.</p></div>';
}
