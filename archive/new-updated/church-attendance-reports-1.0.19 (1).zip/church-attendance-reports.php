<?php
/**
 * Plugin Name: Church Attendance Reports (Improved)
 * Description: Manages church attendance reports with custom admin menus and role-based access.
 * Version: 1.0.19
 * Author: Bo Kelleher
 */

if (!defined('ABSPATH')) exit;

define('CHURCH_ATTENDANCE_PLUGIN_FILE', __FILE__);
define('CAR_PLUGIN_BASENAME', plugin_basename(__FILE__));

register_activation_hook(__FILE__, 'car_activate_plugin');

function car_activate_plugin() {
    require_once plugin_dir_path(__FILE__) . 'includes/db-setup.php';
    car_create_plugin_tables();
}

// Load components
require_once plugin_dir_path(__FILE__) . 'includes/menu-switch.php';

// Add settings link on plugin list page
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function($links) {
    $url = admin_url('admin.php?page=car_reports');
    $settings_link = '<a href="' . esc_url($url) . '">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
});
