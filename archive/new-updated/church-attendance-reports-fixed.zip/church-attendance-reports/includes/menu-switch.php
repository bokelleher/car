<?php
// Placeholder for menu-switch.php.
