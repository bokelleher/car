<?php
// Placeholder for meta-display-box.php.
