<?php
// Placeholder for access-control.php.
