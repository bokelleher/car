<?php
// Placeholder for shortcode-church-dashboard.php.
