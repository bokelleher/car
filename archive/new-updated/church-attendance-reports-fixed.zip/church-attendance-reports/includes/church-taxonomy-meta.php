<?php
// Placeholder for church-taxonomy-meta.php.
