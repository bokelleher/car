<?php
// Placeholder for db-setup.php.
