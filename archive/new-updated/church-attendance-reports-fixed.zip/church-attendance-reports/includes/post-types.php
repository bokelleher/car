<?php
// Placeholder for post-types.php.
