<?php
// Placeholder for car-generate-churches.php.
