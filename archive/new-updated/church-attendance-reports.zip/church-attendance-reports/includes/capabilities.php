<?php
// Placeholder for capabilities.php.
