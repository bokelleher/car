<?php
// Placeholder for taxonomy-church.php.
