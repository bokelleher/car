<?php
// Placeholder for admin-user-church-list.php.
