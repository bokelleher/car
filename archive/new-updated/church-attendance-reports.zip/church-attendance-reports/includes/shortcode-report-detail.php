<?php
// Placeholder for shortcode-report-detail.php.
