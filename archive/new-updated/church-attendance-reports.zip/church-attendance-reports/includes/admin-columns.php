<?php
// Placeholder for admin-columns.php.
