<?php
// Placeholder for church-admin.php.
