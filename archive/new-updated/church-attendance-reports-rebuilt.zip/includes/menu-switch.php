<?php
add_action('admin_menu', function() {
    add_menu_page(
        'Attendance Reports',
        'Attendance Reports',
        'read',
        'car_reports',
        function () {
            echo '<div class="wrap"><h1>Attendance Reports</h1><p>This page will show a summary or links to key reporting functions.</p></div>';
        },
        'dashicons-groups',
        25
    );
});
